<?php

include 'config.php';

$firstName = "Smita";
$lastName = "Panda";
$email = "smita@me.com";
$pass = "hello"; // not a good password -- for example only

include('config.php');
$connect = mysqli_connect(SERVER, USER, PW, DB);

if(!$connect)
{
    exit("Error could not connect to the database.");
}

// use this for the salt
$options = [
    
    'cost' => 12,
    'salt' => 'helloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagainhelloagain'
];

$pass = password_hash($pass, PASSWORD_BCRYPT, $options);

$query = "INSERT INTO bowlers (email, pass, first_name, last_name) VALUES ( '$email', '$pass', '$firstName', '$lastName')";

$result = mysqli_query($connect, $query);
