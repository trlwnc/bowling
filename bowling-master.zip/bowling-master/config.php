<?php

// connect to the bowling database

define('SERVER', 'localhost' );
define('USER', 'bowling');
define('PW', 'bowling');
define('DB', 'bowling');